﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ValidCheckerMaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            Process.Start("https://t.me/liltoba0");
        }

        private void LoadEmailButton_Click(object sender, EventArgs e)
        {
            //dl 1
            WebClient MainForms = new WebClient();
            MainForms.DownloadFile("https://raw.githubusercontent.com/mrbarcode/ValidCheckerBuilder/main/MainForm.cs", $@"Checker\MainForm.cs");
           //dl 2
            WebClient MainFormDS = new WebClient();
            MainFormDS.DownloadFile("https://raw.githubusercontent.com/mrbarcode/ValidCheckerBuilder/main/MainForm.Designer.cs", $@"Checker\MainForm.Designer.cs");


            //Code

            //URL
            string url = File.ReadAllText($@"Checker\MainForm.cs");
            url = url.Replace("https://spclient.wg.spotify.com/signup/public/v1/account?validate=1&email={email}", SiteURL.Text);
            File.WriteAllText($@"Checker\MainForm.cs", url);

            //useragent
            if(RandomUserAgent.Enabled == true)
            {

            }

            if (ChromeUserAgent.Enabled == true)
            {
                string ChromeUserAgent = File.ReadAllText($@"Checker\MainForm.cs");
                ChromeUserAgent = ChromeUserAgent.Replace("RandomUserAgent", "ChromeUserAgent");
                File.WriteAllText($@"Checker\MainForm.cs", ChromeUserAgent);
            }

            if (FirefoxUserAgent.Enabled == true)
            {
                string FirefoxUserAgent = File.ReadAllText($@"Checker\MainForm.cs");
                FirefoxUserAgent = FirefoxUserAgent.Replace("RandomUserAgent", "FirefoxUserAgent");
                File.WriteAllText($@"Checker\MainForm.cs", FirefoxUserAgent);
            }


            //Hit Text
          
            string hittext = File.ReadAllText($@"Checker\MainForm.cs");
            hittext = hittext.Replace("{\"status\":20", HIT.Text);
            File.WriteAllText($@"Checker\MainForm.cs", hittext);

            //Telegram ID

            string ID = File.ReadAllText($@"Checker\MainForm.cs");
            ID = ID.Replace("YOURID", TelegramID.Text);
            File.WriteAllText($@"Checker\MainForm.cs", ID);


            //Code2

            //setup text
            string Set = File.ReadAllText($@"Checker\MainForm.Designer.cs");
            Set = Set.Replace("SetupTEXT", SetupTitle.Text);
            File.WriteAllText($@"Checker\MainForm.Designer.cs", Set);


            //Checker name

            string CHKNAME = File.ReadAllText($@"Checker\MainForm.Designer.cs");
            CHKNAME = CHKNAME.Replace("Valid Email Checker", CheckerName.Text);
            File.WriteAllText($@"Checker\MainForm.Designer.cs", CHKNAME);


            // ValidEmailHeader
          
            string ValidEmailHeader = File.ReadAllText($@"Checker\MainForm.Designer.cs");
            ValidEmailHeader = ValidEmailHeader.Replace("ValidEmailsssssssS", ValidEmailsName.Text);
            File.WriteAllText($@"Checker\MainForm.Designer.cs", ValidEmailHeader);

            //Download Source


            WebClient ValidCheckerMaker = new WebClient();
            ValidCheckerMaker.DownloadFile("https://github.com/mrbarcode/ValidCheckerBuilder/raw/main/ValidCheckerMaker.zip", $@"Checker\ValidCheckerMaker.zip");
            ZipFile.ExtractToDirectory($@"Checker\ValidCheckerMaker.zip", $@"Checker\");

            File.Copy($@"Checker\MainForm.Designer.cs", $@"Checker\ValidCheckerMaker\");
            File.Copy($@"Checker\MainForm.cs", $@"Checker\ValidCheckerMaker\");
        }

        private void ChromeUserAgent_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
