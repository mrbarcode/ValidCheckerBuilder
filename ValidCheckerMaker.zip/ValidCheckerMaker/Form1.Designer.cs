﻿
namespace ValidCheckerMaker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.siticoneAnimateWindow1 = new Siticone.UI.WinForms.SiticoneAnimateWindow(this.components);
            this.siticoneDragControl1 = new Siticone.UI.WinForms.SiticoneDragControl(this.components);
            this.siticoneElipse1 = new Siticone.UI.WinForms.SiticoneElipse(this.components);
            this.siticonePanel1 = new Siticone.UI.WinForms.SiticonePanel();
            this.siticonePanel2 = new Siticone.UI.WinForms.SiticonePanel();
            this.SetupGB = new Siticone.UI.WinForms.SiticoneGroupBox();
            this.LoadEmailButton = new Siticone.UI.WinForms.SiticoneButton();
            this.MinimizeButton = new Siticone.UI.WinForms.SiticoneControlBox();
            this.CloseButton = new Siticone.UI.WinForms.SiticoneControlBox();
            this.Title = new System.Windows.Forms.Label();
            this.SiteURL = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.HIT = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.CheckerName = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.siticoneLabel1 = new Siticone.UI.WinForms.SiticoneLabel();
            this.TelegramID = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.siticoneMaterialTextBox5 = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.SetupTitle = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.ValidEmailsName = new Siticone.UI.WinForms.SiticoneMaterialTextBox();
            this.siticoneButton1 = new Siticone.UI.WinForms.SiticoneButton();
            this.siticoneCheckBox3 = new Siticone.UI.WinForms.SiticoneCheckBox();
            this.siticoneCheckBox4 = new Siticone.UI.WinForms.SiticoneCheckBox();
            this.ChromeUserAgent = new Siticone.UI.WinForms.SiticoneCheckBox();
            this.FirefoxUserAgent = new Siticone.UI.WinForms.SiticoneCheckBox();
            this.RandomUserAgent = new Siticone.UI.WinForms.SiticoneCheckBox();
            this.siticonePanel1.SuspendLayout();
            this.siticonePanel2.SuspendLayout();
            this.SetupGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // siticoneDragControl1
            // 
            this.siticoneDragControl1.TargetControl = this.siticonePanel2;
            // 
            // siticonePanel1
            // 
            this.siticonePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.siticonePanel1.Controls.Add(this.siticoneButton1);
            this.siticonePanel1.Controls.Add(this.SetupGB);
            this.siticonePanel1.Controls.Add(this.siticonePanel2);
            this.siticonePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.siticonePanel1.Location = new System.Drawing.Point(0, 0);
            this.siticonePanel1.Name = "siticonePanel1";
            this.siticonePanel1.ShadowDecoration.Parent = this.siticonePanel1;
            this.siticonePanel1.Size = new System.Drawing.Size(397, 546);
            this.siticonePanel1.TabIndex = 0;
            // 
            // siticonePanel2
            // 
            this.siticonePanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.siticonePanel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.siticonePanel2.Controls.Add(this.Title);
            this.siticonePanel2.Controls.Add(this.MinimizeButton);
            this.siticonePanel2.Controls.Add(this.CloseButton);
            this.siticonePanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.siticonePanel2.Location = new System.Drawing.Point(0, 0);
            this.siticonePanel2.Name = "siticonePanel2";
            this.siticonePanel2.ShadowDecoration.Parent = this.siticonePanel2;
            this.siticonePanel2.Size = new System.Drawing.Size(397, 34);
            this.siticonePanel2.TabIndex = 0;
            // 
            // SetupGB
            // 
            this.SetupGB.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.SetupGB.Controls.Add(this.RandomUserAgent);
            this.SetupGB.Controls.Add(this.FirefoxUserAgent);
            this.SetupGB.Controls.Add(this.ChromeUserAgent);
            this.SetupGB.Controls.Add(this.siticoneCheckBox4);
            this.SetupGB.Controls.Add(this.siticoneCheckBox3);
            this.SetupGB.Controls.Add(this.ValidEmailsName);
            this.SetupGB.Controls.Add(this.SetupTitle);
            this.SetupGB.Controls.Add(this.siticoneMaterialTextBox5);
            this.SetupGB.Controls.Add(this.TelegramID);
            this.SetupGB.Controls.Add(this.siticoneLabel1);
            this.SetupGB.Controls.Add(this.CheckerName);
            this.SetupGB.Controls.Add(this.HIT);
            this.SetupGB.Controls.Add(this.SiteURL);
            this.SetupGB.Controls.Add(this.LoadEmailButton);
            this.SetupGB.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.SetupGB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.SetupGB.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetupGB.ForeColor = System.Drawing.Color.White;
            this.SetupGB.Location = new System.Drawing.Point(12, 161);
            this.SetupGB.Name = "SetupGB";
            this.SetupGB.ShadowDecoration.Parent = this.SetupGB;
            this.SetupGB.Size = new System.Drawing.Size(373, 373);
            this.SetupGB.TabIndex = 1;
            this.SetupGB.Text = "Checker Builder";
            this.SetupGB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LoadEmailButton
            // 
            this.LoadEmailButton.CheckedState.Parent = this.LoadEmailButton;
            this.LoadEmailButton.CustomImages.Parent = this.LoadEmailButton;
            this.LoadEmailButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.LoadEmailButton.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadEmailButton.ForeColor = System.Drawing.Color.White;
            this.LoadEmailButton.HoveredState.Parent = this.LoadEmailButton;
            this.LoadEmailButton.Location = new System.Drawing.Point(13, 331);
            this.LoadEmailButton.Name = "LoadEmailButton";
            this.LoadEmailButton.ShadowDecoration.Parent = this.LoadEmailButton;
            this.LoadEmailButton.Size = new System.Drawing.Size(212, 30);
            this.LoadEmailButton.TabIndex = 0;
            this.LoadEmailButton.Text = "BUILD";
            this.LoadEmailButton.Click += new System.EventHandler(this.LoadEmailButton_Click);
            // 
            // MinimizeButton
            // 
            this.MinimizeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MinimizeButton.ControlBoxType = Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.MinimizeButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.MinimizeButton.HoveredState.Parent = this.MinimizeButton;
            this.MinimizeButton.IconColor = System.Drawing.Color.White;
            this.MinimizeButton.Location = new System.Drawing.Point(277, 0);
            this.MinimizeButton.Name = "MinimizeButton";
            this.MinimizeButton.ShadowDecoration.Parent = this.MinimizeButton;
            this.MinimizeButton.Size = new System.Drawing.Size(60, 35);
            this.MinimizeButton.TabIndex = 4;
            // 
            // CloseButton
            // 
            this.CloseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.CloseButton.HoveredState.Parent = this.CloseButton;
            this.CloseButton.IconColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(337, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.ShadowDecoration.Parent = this.CloseButton;
            this.CloseButton.Size = new System.Drawing.Size(60, 35);
            this.CloseButton.TabIndex = 3;
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.BackColor = System.Drawing.Color.Transparent;
            this.Title.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(8, 8);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(130, 17);
            this.Title.TabIndex = 2;
            this.Title.Text = "Valid Checker Builder";
            // 
            // SiteURL
            // 
            this.SiteURL.BorderColor = System.Drawing.Color.Black;
            this.SiteURL.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SiteURL.DefaultText = "";
            this.SiteURL.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SiteURL.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SiteURL.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SiteURL.DisabledState.Parent = this.SiteURL;
            this.SiteURL.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SiteURL.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.SiteURL.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SiteURL.FocusedState.Parent = this.SiteURL;
            this.SiteURL.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SiteURL.HoveredState.Parent = this.SiteURL;
            this.SiteURL.Location = new System.Drawing.Point(13, 88);
            this.SiteURL.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SiteURL.Name = "SiteURL";
            this.SiteURL.PasswordChar = '\0';
            this.SiteURL.PlaceholderText = "URL";
            this.SiteURL.SelectedText = "";
            this.SiteURL.ShadowDecoration.Parent = this.SiteURL;
            this.SiteURL.Size = new System.Drawing.Size(346, 26);
            this.SiteURL.TabIndex = 5;
            // 
            // HIT
            // 
            this.HIT.BorderColor = System.Drawing.Color.Black;
            this.HIT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.HIT.DefaultText = "";
            this.HIT.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.HIT.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.HIT.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.HIT.DisabledState.Parent = this.HIT;
            this.HIT.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.HIT.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.HIT.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.HIT.FocusedState.Parent = this.HIT;
            this.HIT.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.HIT.HoveredState.Parent = this.HIT;
            this.HIT.Location = new System.Drawing.Point(13, 120);
            this.HIT.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.HIT.Name = "HIT";
            this.HIT.PasswordChar = '\0';
            this.HIT.PlaceholderText = "Response.Contains (Good Text Page)";
            this.HIT.SelectedText = "";
            this.HIT.ShadowDecoration.Parent = this.HIT;
            this.HIT.Size = new System.Drawing.Size(226, 26);
            this.HIT.TabIndex = 6;
            // 
            // CheckerName
            // 
            this.CheckerName.BorderColor = System.Drawing.Color.Black;
            this.CheckerName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CheckerName.DefaultText = "";
            this.CheckerName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.CheckerName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.CheckerName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CheckerName.DisabledState.Parent = this.CheckerName;
            this.CheckerName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CheckerName.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.CheckerName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CheckerName.FocusedState.Parent = this.CheckerName;
            this.CheckerName.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CheckerName.HoveredState.Parent = this.CheckerName;
            this.CheckerName.Location = new System.Drawing.Point(13, 49);
            this.CheckerName.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.CheckerName.Name = "CheckerName";
            this.CheckerName.PasswordChar = '\0';
            this.CheckerName.PlaceholderText = "Valid Checker Name";
            this.CheckerName.SelectedText = "";
            this.CheckerName.ShadowDecoration.Parent = this.CheckerName;
            this.CheckerName.Size = new System.Drawing.Size(346, 26);
            this.CheckerName.TabIndex = 7;
            // 
            // siticoneLabel1
            // 
            this.siticoneLabel1.BackColor = System.Drawing.Color.Transparent;
            this.siticoneLabel1.Location = new System.Drawing.Point(13, 161);
            this.siticoneLabel1.Name = "siticoneLabel1";
            this.siticoneLabel1.Size = new System.Drawing.Size(79, 22);
            this.siticoneLabel1.TabIndex = 11;
            this.siticoneLabel1.Text = "UserAgent :";
            // 
            // TelegramID
            // 
            this.TelegramID.BorderColor = System.Drawing.Color.Black;
            this.TelegramID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TelegramID.DefaultText = "";
            this.TelegramID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TelegramID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TelegramID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TelegramID.DisabledState.Parent = this.TelegramID;
            this.TelegramID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TelegramID.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.TelegramID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TelegramID.FocusedState.Parent = this.TelegramID;
            this.TelegramID.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TelegramID.HoveredState.Parent = this.TelegramID;
            this.TelegramID.Location = new System.Drawing.Point(13, 251);
            this.TelegramID.Margin = new System.Windows.Forms.Padding(7, 12, 7, 12);
            this.TelegramID.Name = "TelegramID";
            this.TelegramID.PasswordChar = '\0';
            this.TelegramID.PlaceholderText = "Telegram ID For About";
            this.TelegramID.SelectedText = "";
            this.TelegramID.ShadowDecoration.Parent = this.TelegramID;
            this.TelegramID.Size = new System.Drawing.Size(136, 24);
            this.TelegramID.TabIndex = 14;
            // 
            // siticoneMaterialTextBox5
            // 
            this.siticoneMaterialTextBox5.BorderColor = System.Drawing.Color.Black;
            this.siticoneMaterialTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.siticoneMaterialTextBox5.DefaultText = "";
            this.siticoneMaterialTextBox5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.siticoneMaterialTextBox5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.siticoneMaterialTextBox5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneMaterialTextBox5.DisabledState.Parent = this.siticoneMaterialTextBox5;
            this.siticoneMaterialTextBox5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.siticoneMaterialTextBox5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.siticoneMaterialTextBox5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneMaterialTextBox5.FocusedState.Parent = this.siticoneMaterialTextBox5;
            this.siticoneMaterialTextBox5.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneMaterialTextBox5.HoveredState.Parent = this.siticoneMaterialTextBox5;
            this.siticoneMaterialTextBox5.Location = new System.Drawing.Point(152, 251);
            this.siticoneMaterialTextBox5.Margin = new System.Windows.Forms.Padding(9, 18, 9, 18);
            this.siticoneMaterialTextBox5.Name = "siticoneMaterialTextBox5";
            this.siticoneMaterialTextBox5.PasswordChar = '\0';
            this.siticoneMaterialTextBox5.PlaceholderText = "Title Checker Name";
            this.siticoneMaterialTextBox5.SelectedText = "";
            this.siticoneMaterialTextBox5.ShadowDecoration.Parent = this.siticoneMaterialTextBox5;
            this.siticoneMaterialTextBox5.Size = new System.Drawing.Size(126, 24);
            this.siticoneMaterialTextBox5.TabIndex = 15;
            // 
            // SetupTitle
            // 
            this.SetupTitle.BorderColor = System.Drawing.Color.Black;
            this.SetupTitle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SetupTitle.DefaultText = "";
            this.SetupTitle.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.SetupTitle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.SetupTitle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SetupTitle.DisabledState.Parent = this.SetupTitle;
            this.SetupTitle.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.SetupTitle.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.SetupTitle.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SetupTitle.FocusedState.Parent = this.SetupTitle;
            this.SetupTitle.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.SetupTitle.HoveredState.Parent = this.SetupTitle;
            this.SetupTitle.Location = new System.Drawing.Point(13, 281);
            this.SetupTitle.Margin = new System.Windows.Forms.Padding(12, 28, 12, 28);
            this.SetupTitle.Name = "SetupTitle";
            this.SetupTitle.PasswordChar = '\0';
            this.SetupTitle.PlaceholderText = "Setup Title Text";
            this.SetupTitle.SelectedText = "";
            this.SetupTitle.ShadowDecoration.Parent = this.SetupTitle;
            this.SetupTitle.Size = new System.Drawing.Size(103, 24);
            this.SetupTitle.TabIndex = 16;
            // 
            // ValidEmailsName
            // 
            this.ValidEmailsName.BorderColor = System.Drawing.Color.Black;
            this.ValidEmailsName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ValidEmailsName.DefaultText = "";
            this.ValidEmailsName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ValidEmailsName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ValidEmailsName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ValidEmailsName.DisabledState.Parent = this.ValidEmailsName;
            this.ValidEmailsName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ValidEmailsName.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.ValidEmailsName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ValidEmailsName.FocusedState.Parent = this.ValidEmailsName;
            this.ValidEmailsName.HoveredState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ValidEmailsName.HoveredState.Parent = this.ValidEmailsName;
            this.ValidEmailsName.Location = new System.Drawing.Point(122, 281);
            this.ValidEmailsName.Margin = new System.Windows.Forms.Padding(16, 43, 16, 43);
            this.ValidEmailsName.Name = "ValidEmailsName";
            this.ValidEmailsName.PasswordChar = '\0';
            this.ValidEmailsName.PlaceholderText = "ListView Title Text";
            this.ValidEmailsName.SelectedText = "";
            this.ValidEmailsName.ShadowDecoration.Parent = this.ValidEmailsName;
            this.ValidEmailsName.Size = new System.Drawing.Size(111, 24);
            this.ValidEmailsName.TabIndex = 17;
            // 
            // siticoneButton1
            // 
            this.siticoneButton1.CheckedState.Parent = this.siticoneButton1;
            this.siticoneButton1.CustomImages.Parent = this.siticoneButton1;
            this.siticoneButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.siticoneButton1.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton1.ForeColor = System.Drawing.Color.White;
            this.siticoneButton1.HoveredState.Parent = this.siticoneButton1;
            this.siticoneButton1.Location = new System.Drawing.Point(243, 492);
            this.siticoneButton1.Name = "siticoneButton1";
            this.siticoneButton1.ShadowDecoration.Parent = this.siticoneButton1;
            this.siticoneButton1.Size = new System.Drawing.Size(128, 30);
            this.siticoneButton1.TabIndex = 18;
            this.siticoneButton1.Text = "ABOUT";
            this.siticoneButton1.Click += new System.EventHandler(this.siticoneButton1_Click);
            // 
            // siticoneCheckBox3
            // 
            this.siticoneCheckBox3.AutoSize = true;
            this.siticoneCheckBox3.BackColor = System.Drawing.Color.Transparent;
            this.siticoneCheckBox3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneCheckBox3.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox3.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneCheckBox3.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F);
            this.siticoneCheckBox3.ForeColor = System.Drawing.Color.White;
            this.siticoneCheckBox3.Location = new System.Drawing.Point(246, 123);
            this.siticoneCheckBox3.Name = "siticoneCheckBox3";
            this.siticoneCheckBox3.Size = new System.Drawing.Size(50, 21);
            this.siticoneCheckBox3.TabIndex = 21;
            this.siticoneCheckBox3.Text = "GET";
            this.siticoneCheckBox3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox3.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox3.UncheckedState.BorderThickness = 1;
            this.siticoneCheckBox3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.siticoneCheckBox3.UseVisualStyleBackColor = false;
            // 
            // siticoneCheckBox4
            // 
            this.siticoneCheckBox4.AutoSize = true;
            this.siticoneCheckBox4.BackColor = System.Drawing.Color.Transparent;
            this.siticoneCheckBox4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneCheckBox4.CheckedState.BorderRadius = 2;
            this.siticoneCheckBox4.CheckedState.BorderThickness = 0;
            this.siticoneCheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.siticoneCheckBox4.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F);
            this.siticoneCheckBox4.ForeColor = System.Drawing.Color.White;
            this.siticoneCheckBox4.Location = new System.Drawing.Point(302, 123);
            this.siticoneCheckBox4.Name = "siticoneCheckBox4";
            this.siticoneCheckBox4.Size = new System.Drawing.Size(58, 21);
            this.siticoneCheckBox4.TabIndex = 22;
            this.siticoneCheckBox4.Text = "POST";
            this.siticoneCheckBox4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.siticoneCheckBox4.UncheckedState.BorderRadius = 2;
            this.siticoneCheckBox4.UncheckedState.BorderThickness = 1;
            this.siticoneCheckBox4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.siticoneCheckBox4.UseVisualStyleBackColor = false;
            // 
            // ChromeUserAgent
            // 
            this.ChromeUserAgent.AutoSize = true;
            this.ChromeUserAgent.BackColor = System.Drawing.Color.Transparent;
            this.ChromeUserAgent.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ChromeUserAgent.CheckedState.BorderRadius = 2;
            this.ChromeUserAgent.CheckedState.BorderThickness = 0;
            this.ChromeUserAgent.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ChromeUserAgent.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F);
            this.ChromeUserAgent.ForeColor = System.Drawing.Color.White;
            this.ChromeUserAgent.Location = new System.Drawing.Point(12, 188);
            this.ChromeUserAgent.Name = "ChromeUserAgent";
            this.ChromeUserAgent.Size = new System.Drawing.Size(134, 21);
            this.ChromeUserAgent.TabIndex = 23;
            this.ChromeUserAgent.Text = "ChromeUserAgent";
            this.ChromeUserAgent.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ChromeUserAgent.UncheckedState.BorderRadius = 2;
            this.ChromeUserAgent.UncheckedState.BorderThickness = 1;
            this.ChromeUserAgent.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ChromeUserAgent.UseVisualStyleBackColor = false;
            this.ChromeUserAgent.CheckedChanged += new System.EventHandler(this.ChromeUserAgent_CheckedChanged);
            // 
            // FirefoxUserAgent
            // 
            this.FirefoxUserAgent.AutoSize = true;
            this.FirefoxUserAgent.BackColor = System.Drawing.Color.Transparent;
            this.FirefoxUserAgent.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FirefoxUserAgent.CheckedState.BorderRadius = 2;
            this.FirefoxUserAgent.CheckedState.BorderThickness = 0;
            this.FirefoxUserAgent.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FirefoxUserAgent.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F);
            this.FirefoxUserAgent.ForeColor = System.Drawing.Color.White;
            this.FirefoxUserAgent.Location = new System.Drawing.Point(152, 188);
            this.FirefoxUserAgent.Name = "FirefoxUserAgent";
            this.FirefoxUserAgent.Size = new System.Drawing.Size(127, 21);
            this.FirefoxUserAgent.TabIndex = 24;
            this.FirefoxUserAgent.Text = "FirefoxUserAgent";
            this.FirefoxUserAgent.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.FirefoxUserAgent.UncheckedState.BorderRadius = 2;
            this.FirefoxUserAgent.UncheckedState.BorderThickness = 1;
            this.FirefoxUserAgent.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.FirefoxUserAgent.UseVisualStyleBackColor = false;
            // 
            // RandomUserAgent
            // 
            this.RandomUserAgent.AutoSize = true;
            this.RandomUserAgent.BackColor = System.Drawing.Color.Transparent;
            this.RandomUserAgent.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RandomUserAgent.CheckedState.BorderRadius = 2;
            this.RandomUserAgent.CheckedState.BorderThickness = 0;
            this.RandomUserAgent.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RandomUserAgent.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F);
            this.RandomUserAgent.ForeColor = System.Drawing.Color.White;
            this.RandomUserAgent.Location = new System.Drawing.Point(12, 215);
            this.RandomUserAgent.Name = "RandomUserAgent";
            this.RandomUserAgent.Size = new System.Drawing.Size(137, 21);
            this.RandomUserAgent.TabIndex = 25;
            this.RandomUserAgent.Text = "RandomUserAgent";
            this.RandomUserAgent.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.RandomUserAgent.UncheckedState.BorderRadius = 2;
            this.RandomUserAgent.UncheckedState.BorderThickness = 1;
            this.RandomUserAgent.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.RandomUserAgent.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 546);
            this.Controls.Add(this.siticonePanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Valid Checker Builder";
            this.siticonePanel1.ResumeLayout(false);
            this.siticonePanel2.ResumeLayout(false);
            this.siticonePanel2.PerformLayout();
            this.SetupGB.ResumeLayout(false);
            this.SetupGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Siticone.UI.WinForms.SiticoneAnimateWindow siticoneAnimateWindow1;
        private Siticone.UI.WinForms.SiticoneDragControl siticoneDragControl1;
        private Siticone.UI.WinForms.SiticonePanel siticonePanel2;
        private System.Windows.Forms.Label Title;
        private Siticone.UI.WinForms.SiticoneControlBox MinimizeButton;
        private Siticone.UI.WinForms.SiticoneControlBox CloseButton;
        private Siticone.UI.WinForms.SiticoneElipse siticoneElipse1;
        private Siticone.UI.WinForms.SiticonePanel siticonePanel1;
        private Siticone.UI.WinForms.SiticoneGroupBox SetupGB;
        private Siticone.UI.WinForms.SiticoneButton LoadEmailButton;
        private Siticone.UI.WinForms.SiticoneLabel siticoneLabel1;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox CheckerName;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox HIT;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox SiteURL;
        private Siticone.UI.WinForms.SiticoneButton siticoneButton1;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox ValidEmailsName;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox SetupTitle;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox siticoneMaterialTextBox5;
        private Siticone.UI.WinForms.SiticoneMaterialTextBox TelegramID;
        private Siticone.UI.WinForms.SiticoneCheckBox RandomUserAgent;
        private Siticone.UI.WinForms.SiticoneCheckBox FirefoxUserAgent;
        private Siticone.UI.WinForms.SiticoneCheckBox ChromeUserAgent;
        private Siticone.UI.WinForms.SiticoneCheckBox siticoneCheckBox4;
        private Siticone.UI.WinForms.SiticoneCheckBox siticoneCheckBox3;
    }
}

